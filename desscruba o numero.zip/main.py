n=0
import random
from random import randint
nu=(random.randint(1,10))
es=123456789008080
while es!= nu :
  es=int(input("Tente adivinhar o número de 1 a 10"))
  if es == nu :
    n=n+1
    print("Parabéns. Você acertou em", n,"terntaivas")
  elif es <= nu :
    n=n+1
    print("Errou... é maior")
  elif es >= nu :
    n=n+1
    print("Errou... é menor")
